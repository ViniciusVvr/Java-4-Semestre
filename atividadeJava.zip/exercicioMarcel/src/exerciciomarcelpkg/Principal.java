package exerciciomarcelpkg;

import java.util.Scanner;
import java.util.Locale;


import exerciciomarcelpkg.Secretaria;
import exerciciomarcelpkg.Motorista;
import exerciciomarcelpkg.Funcionario;

public class Principal {
	public static void main(String[] args) {
		
		Locale.setDefault(Locale.US);
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Digite a funcao do Funcionario:  [Motorista, Secretaria, Outro]");
		String funcao = input.next();
		System.out.println("Digite as horas trabalhadas no mes: ");
		int horas = input.nextInt();
		
		Funcionario func = new Funcionario();
		if(funcao.equals("Motorista")) {
			
			Motorista mot = new Motorista();
			System.out.print("Digite o nome: ");
			mot.setnome(input.next());
			System.out.print("Digite o numero da matricula: ");
			mot.setnumeroDaMatricula(input.next());
			System.out.print("Digite a data de nascimento: ");
			mot.setNascimento(input.next());
			System.out.print("Digite o telefone fixo: ");
			mot.settelefoneFixo(input.next());
			System.out.print("Digite o telefone celular: ");
			mot.setcelular(input.next());
			System.out.print("Digite o valor por hora: ");
			mot.setvalHora(input.nextInt());
			System.out.print("Digite o email: ");
			mot.setEmail(input.next());
			System.out.print("Digite a data de admissao: ");
			mot.setDataAdmissao(input.next());
			System.out.print("Digite a data de demissao: ");
			mot.setDataDemissao(input.next());
			
			System.out.printf("Digite o numero da CNH: ");
			mot.setcodigoDaCNH(input.next());
			System.out.printf("Digite a categoria da habilitacao: A - D ");
			mot.setCategoria(input.next().charAt(0));
			System.out.printf("Digite a data da primeira habilitacao: ");
			mot.setdatePriHab(input.next());
			System.out.printf("Digite a data de validade: ");
			mot.setdateVal(input.next());
			
			mot.getDadosMotorista(horas);
		}else if(funcao.equals("Secretaria")) {
			
			Secretaria sec = new Secretaria();
			System.out.print("Digite o nome: ");
			sec.setnome(input.next());
			System.out.print("Digite o numero da matricula: ");
			sec.setnumeroDaMatricula(input.next());
			System.out.print("Digite a data de nascimento: ");
			sec.setNascimento(input.next());
			System.out.print("Digite o telefone fixo: ");
			sec.settelefoneFixo(input.next());
			System.out.print("Digite o telefone celular: ");
			sec.setcelular(input.next());
			System.out.print("Digite o valor por hora: ");
			sec.setvalHora(input.nextInt());
			System.out.print("Digite o email: ");
			sec.setEmail(input.next());
			System.out.print("Digite a data de admissao: ");
			sec.setDataAdmissao(input.next());
			System.out.print("Digite a data de demissao: ");
			sec.setDataDemissao(input.next());
			
			System.out.print("Digite a quantidade de idiomas: ");
			sec.setquantidaDeIdiomas(input.nextInt());
			System.out.print("Digite o nome da graduacao: ");
			sec.setanoDeInicioGraduacao(input.next());
			System.out.print("Digite o ano de inicio da graduacao: ");
			sec.setanoDeInicioGraduacao(input.next());
			
			sec.getDadosSecretaria(horas);
		}else if(funcao.equals("Outro")) {
			
			func.setnome(input.next());
			System.out.print("Digite o numero da matricula: ");
			func.setnumeroDaMatricula(input.next());
			System.out.print("Digite a data de nascimento: ");
			func.setNascimento(input.next());
			System.out.print("Digite o telefone fixo: ");
			func.settelefoneFixo(input.next());
			System.out.print("Digite o telefone celular: ");
			func.setcelular(input.next());
			System.out.print("Digite o valor por hora: ");
			func.setvalHora(input.nextInt());
			System.out.print("Digite o email: ");
			func.setEmail(input.next());
			System.out.print("Digite a data de admissao: ");
			func.setDataAdmissao(input.next());
			System.out.print("Digite a data de demissao: ");
			func.setDataDemissao(input.next());
			
			func.getDadosFuncionario();
			func.calculo(horas);
		}
		
		input.close();
	}
}
