package exerciciomarcelpkg;

public class Funcionario {
	
	private String nome;
	private String numeroDaMatricula;
	private String Nascimento;
	private String telefoneFixo;
	private String celular;
	private double valHora;
	private String email;
	private String dataAdmissao;
	private String dataDemissao;
	
	public Funcionario() {}
	
	public String getnome() {
		return nome;
}

	public void setnome(String nome) {
		this.nome = nome;
}

	public String getnumeroDaMatricula() {
		return numeroDaMatricula;
}

	public void setnumeroDaMatricula(String numeroDaMatricula) {
		this.numeroDaMatricula = numeroDaMatricula;
}

	public String getNascimento() {
		return Nascimento;
}

	public void setNascimento(String Nascimento) {
		this.Nascimento = Nascimento;
}

	public String gettelefoneFixo() {
		return telefoneFixo;
}

	public void settelefoneFixo(String telefoneFixo) {
		telefoneFixo = telefoneFixo;
}

	public String getcelular() {
		return celular;
}

	public void setcelular(String celular) {
		celular = celular;
}

	public double getvalHora() {
		return valHora;
}

	public void setvalHora(double valHora) {
		this.valHora = valHora;
}

	public String getEmail() {
		return email;
}

	public void setEmail(String email) {
		this.email = email;
}

	public String getDataAdmissao() {
		return dataAdmissao;
}

	public void setDataAdmissao(String dataAdmissao) {
		this.dataAdmissao = dataAdmissao;
}

	public String getDataDemissao() {
		return dataDemissao;
}

	public void setDataDemissao(String dataDemissao) {
		this.dataDemissao = dataDemissao;
}
	
public void getDadosFuncionario() {
		
		System.out.println( "nome = " + this.nome + "\nnumeroDaMatricula = " + this.numeroDaMatricula
				+ "\nNascimento = "+ this.Nascimento + "\ntelefoneFixo = " + this.telefoneFixo+ "\ncelular = " + this.celular
				+ "\nvalHora = " + this.valHora+ "\nemail = " + this.email + "\ndataAdmissao = " + this.dataAdmissao
				+ "\ndataDemissao = " + this.dataDemissao);
		
}
	
	public double calculo(int horas) {
		return horas * valHora;
}
	
	
}
