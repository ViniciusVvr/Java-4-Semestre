package exerciciomarcelpkg;

public class Secretaria extends Funcionario{
	
	private Integer quantidaDeIdiomas;
	private String Graduacao;
	private String anoDeInicioGraduacao;
	
	public Secretaria() {
		
}

	public Secretaria(Integer quantidaDeIdiomas, String Graduacao, String anoDeInicioGraduacao) {
		this.quantidaDeIdiomas = quantidaDeIdiomas;
		
		this.Graduacao = Graduacao;
		
		this.anoDeInicioGraduacao = anoDeInicioGraduacao;
}

	public Integer getquantidaDeIdiomas() {
		
		return quantidaDeIdiomas;
}

	public void setquantidaDeIdiomas(Integer quantidaDeIdiomas) {
		
		this.quantidaDeIdiomas = quantidaDeIdiomas;
}

	public String getGraduacao() {
		
		return Graduacao;
}

	public void setGraduacao(String Graduacao) {
		
		this.Graduacao = Graduacao;
}

	
	public String getanoDeInicioGraduacao() {
		return anoDeInicioGraduacao;
}

	public void setanoDeInicioGraduacao(String anoDeInicioGraduacao) {
		
		this.anoDeInicioGraduacao = anoDeInicioGraduacao;
}
	
	public double calculo(int horas) {
		
		return horas * 3.80 * getvalHora();
}
	
	public void getDadosSecretaria(int horas) {
		getDadosFuncionario();
		
		System.out.println("Quantidade de Idiomas: " + quantidaDeIdiomas);
		
		System.out.println("Nome da Graduacao: " + Graduacao);
		
		System.out.println("Ano de inicio da graduacao: " + anoDeInicioGraduacao);
		
		System.out.println("Salario: " + calculo(horas));
		
}
	
}
