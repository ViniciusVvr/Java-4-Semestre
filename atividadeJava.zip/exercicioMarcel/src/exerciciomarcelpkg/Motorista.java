package exerciciomarcelpkg;

public class Motorista extends Funcionario{
	
	private String codigoDaCNH;
	private char categoria;
	private String datePriHab;
	private String dateVal;
	
	public Motorista() {
		
	}

	public Motorista(String codigoDaCNH, char categoria, String datePriHab, String dateVal) {
		this.codigoDaCNH = codigoDaCNH;
		this.categoria = categoria;
		this.datePriHab = datePriHab;
		this.dateVal = dateVal;
	}

	public String getcodigoDaCNH() {
		return codigoDaCNH;
	}

	public void setcodigoDaCNH(String codigoDaCNH) {
		this.codigoDaCNH = codigoDaCNH;
	}

	public char getCategoria() {
		return categoria;
	}

	public void setCategoria(char categoria) {
		this.categoria = categoria;
	}

	public String getdatePriHab() {
		return datePriHab;
	}

	public void setdatePriHab(String datePriHab) {
		this.datePriHab = datePriHab;
	}

	public String getdateVal() {
		return dateVal;
	}

	public void setdateVal(String dateVal) {
		this.dateVal = dateVal;
	}
	
	public double calculo(int horas) {
		double salario = 0;
		
		if(this.categoria == 'A') {
			salario = horas * 3 * getvalHora();
		}
		
		if(this.categoria == 'B') {
			salario = horas * 4 * getvalHora();
		}
		
		if(this.categoria == 'C') {
			salario = horas * 6 * getvalHora();
		}
		
		if(this.categoria == 'D') {
			salario = horas * 5 * getvalHora();
		}
		
		return salario;
	}
	
	public void getDadosMotorista(int horas) {
		
		getDadosFuncionario();
		System.out.println("Numero da CNH: " + codigoDaCNH);
		System.out.println("Categoria: " + categoria);
		System.out.println("Data da Primeria Habilitacao: " + datePriHab);
		System.out.println("Data de Validade: " + dateVal);
		System.out.println("Salario: " + calculo(horas));
		
	}
}
